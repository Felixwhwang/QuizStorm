<?php defined('ABSPATH') OR die('restricted access');?>

<div class="exc-panel">
	<div class="exc-panel-header">
            <h2>
					Page title
            </h2>
        </div>
	
	<strong>
		
		<ol>
			<li>Display installed addons</li>
		</ol>
	</strong>
</div>