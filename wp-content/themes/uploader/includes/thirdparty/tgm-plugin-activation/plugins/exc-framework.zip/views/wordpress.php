<div class="exc-panel exc-wp-skin">

		<?php $this->form->get_html( $_config, $_active_form );?>
		<?php $this->form->get_form_settings( $_name, array('_active_form' => $_active_form ) );?>

</div>